package com.esrx.services.prescriber.config;

import java.io.IOException;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean;

@Configuration
public class HibernateConfiguration {
	
	@Bean
	public AnnotationSessionFactoryBean sessionFactory(DataSource dataSource,
			ResourceLoader resourceLoader) throws IOException {
		Properties props = new Properties();
		props.load(resourceLoader.getResource("classpath:common-hibernate.properties").getInputStream());
		
		AnnotationSessionFactoryBean bean = new AnnotationSessionFactoryBean();
		bean.setDataSource(dataSource);
		bean.setPackagesToScan("com.esrx.services.prescriber_access_management.domain");
		bean.setHibernateProperties(props);
		return bean;
	}

}
