package com.esrx.services.prescriber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

//@SpringBootApplication(exclude={ErrorMvcAutoConfiguration.class})
@SpringBootApplication()
@ImportResource({ 
	"classpath:context/aop-context.xml",
	"classpath:context/transaction-context.xml"})
public class Main {
	
	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}
	
}
