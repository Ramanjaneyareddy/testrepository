package com.esrx.services.prescriber.config;

import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Component;

import com.esrx.inf.spring.boot.autoconfigure.security.HttpSecurityConfigurer;

@Component
public class WebSecurityConfiguration implements HttpSecurityConfigurer {
	
	@Override
	public void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers(HttpMethod.POST, "/userrole/**").permitAll()
				.antMatchers(HttpMethod.POST, "/auditlog/**").permitAll()
				.antMatchers(HttpMethod.POST, "/saveEmail/**").permitAll()
				.antMatchers(HttpMethod.POST, "/maintenanceschedule/**").permitAll()
				.antMatchers(HttpMethod.POST, "/requestentry/**").permitAll()
				.antMatchers(HttpMethod.POST, "/usernpimap/**").permitAll();
	}
	
}
