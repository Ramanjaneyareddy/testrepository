package com.esrx.services.prescriber.config;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.esrx.inf.spring.boot.autoconfigure.resteasy.ResteasyResources;
import com.esrx.services.prescriber_access_management.bo.PrescriberAccessManagementBo;
import com.esrx.services.prescriber_access_management.bo.impl.PrescriberAccessManagementBoImpl;
import com.esrx.services.prescriber_access_management.dao.AuditLogDao;
import com.esrx.services.prescriber_access_management.dao.EmailHistoryDao;
import com.esrx.services.prescriber_access_management.dao.MaintenanceWindowDao;
import com.esrx.services.prescriber_access_management.dao.RequestEntryDao;
import com.esrx.services.prescriber_access_management.dao.UserNpiMapDao;
import com.esrx.services.prescriber_access_management.dao.UserRoleDao;
import com.esrx.services.prescriber_access_management.dao.impl.AuditLogDaoImpl;
import com.esrx.services.prescriber_access_management.dao.impl.EmailHistoryDaoImpl;
import com.esrx.services.prescriber_access_management.dao.impl.MaintenanceWindowDaoImpl;
import com.esrx.services.prescriber_access_management.dao.impl.RequestEntryDaoImpl;
import com.esrx.services.prescriber_access_management.dao.impl.UserNpiMapDaoImpl;
import com.esrx.services.prescriber_access_management.dao.impl.UserRoleDaoImpl;
import com.esrx.services.prescriber_access_management.jaxrs.PrescriberAccessManagementAuditLogResource;
import com.esrx.services.prescriber_access_management.jaxrs.PrescriberAccessManagementMaintenanceScheduleResource;
import com.esrx.services.prescriber_access_management.jaxrs.PrescriberAccessManagementRequestEntryResource;
import com.esrx.services.prescriber_access_management.jaxrs.PrescriberAccessManagementUserNpiMapResource;
import com.esrx.services.prescriber_access_management.jaxrs.PrescriberAccessManagementUserRoleResource;
import com.esrx.services.prescriber_access_management.jaxrs.PrescriberAccessmanagementEmailHistoryResource;
import com.esrx.services.prescriber_access_management.jaxrs.impl.PrescriberAccessManagementAuditLogResourceImpl;
import com.esrx.services.prescriber_access_management.jaxrs.impl.PrescriberAccessManagementMaintenanceScheduleResourceImpl;
import com.esrx.services.prescriber_access_management.jaxrs.impl.PrescriberAccessManagementRequestEntryResourceImpl;
import com.esrx.services.prescriber_access_management.jaxrs.impl.PrescriberAccessManagementUserNpiMapResourceImpl;
import com.esrx.services.prescriber_access_management.jaxrs.impl.PrescriberAccessManagementUserRoleResourceImpl;
import com.esrx.services.prescriber_access_management.jaxrs.impl.PrescriberAccessmanagementEmailHistoryResourceImpl;

@Configuration
public class ComponentConfiguration {
	
	//DAO Configuration
	
	@Bean
	public RequestEntryDao requestEntryDao(SessionFactory sessionFactory) {
		return new RequestEntryDaoImpl(sessionFactory);
	}
	
	@Bean
	public UserNpiMapDao userNpiMapDao(SessionFactory sessionFactory) {
		return new UserNpiMapDaoImpl(sessionFactory);
	}
	
	@Bean
	public UserRoleDao userRoleDao(SessionFactory sessionFactory) {
		return new UserRoleDaoImpl(sessionFactory);
	}
	
	@Bean
	public AuditLogDao auditLogDao(SessionFactory sessionFactory) {
		return new AuditLogDaoImpl(sessionFactory);
	}
	
	@Bean
	public EmailHistoryDao emailHistoryDao(SessionFactory sessionFactory) {
		return new EmailHistoryDaoImpl(sessionFactory);
	}
	
	@Bean
	public MaintenanceWindowDao maintenanceWindowDao(SessionFactory sessionFactory) {
		return new MaintenanceWindowDaoImpl(sessionFactory);
	}
	
	//BO Configuration
	
	@Bean
	public PrescriberAccessManagementBo prescriberAccessManagementBo(
			RequestEntryDao requestEntryDao, UserNpiMapDao userNpiMapDao,
			UserRoleDao userRoleDao, AuditLogDao auditLogDao,
			EmailHistoryDao emailHistoryDao,
			MaintenanceWindowDao maintenanceWindowDao) {
		PrescriberAccessManagementBoImpl bean = new PrescriberAccessManagementBoImpl();
		bean.setAuditLogDao(auditLogDao);
		bean.setEmailHistoryDao(emailHistoryDao);
		bean.setMaintenanceWindowDao(maintenanceWindowDao);
		bean.setRequestEntryDao(requestEntryDao);
		bean.setUserNpiMapDao(userNpiMapDao);
		bean.setUserRoleDao(userRoleDao);
		return bean;
	}
	
	//Resource Configuration
	
	@Bean
	public PrescriberAccessManagementAuditLogResource prescriberAccessManagementAuditLogResource(PrescriberAccessManagementBo prescriberAccessManagementBo) {
		PrescriberAccessManagementAuditLogResourceImpl bean = new PrescriberAccessManagementAuditLogResourceImpl(prescriberAccessManagementBo);
		return bean;
	}
	
	@Bean
	public PrescriberAccessmanagementEmailHistoryResource prescriberAccessmanagementEmailHistoryResource(PrescriberAccessManagementBo prescriberAccessManagementBo) {
		PrescriberAccessmanagementEmailHistoryResourceImpl bean = new PrescriberAccessmanagementEmailHistoryResourceImpl(prescriberAccessManagementBo);
		return bean;
	}
	
	@Bean
	public PrescriberAccessManagementMaintenanceScheduleResource prescriberAccessManagementMaintenanceScheduleResource(PrescriberAccessManagementBo prescriberAccessManagementBo) {
		PrescriberAccessManagementMaintenanceScheduleResourceImpl bean = new PrescriberAccessManagementMaintenanceScheduleResourceImpl(prescriberAccessManagementBo);
		return bean;
	}
	
	@Bean
	public PrescriberAccessManagementRequestEntryResource prescriberAccessManagementRequestEntryResource(PrescriberAccessManagementBo prescriberAccessManagementBo) {
		PrescriberAccessManagementRequestEntryResourceImpl bean = new PrescriberAccessManagementRequestEntryResourceImpl(prescriberAccessManagementBo);
		return bean;
	}
	
	@Bean
	public PrescriberAccessManagementUserNpiMapResource prescriberAccessManagementUserNpiMapResource(PrescriberAccessManagementBo prescriberAccessManagementBo) {
		PrescriberAccessManagementUserNpiMapResourceImpl bean = new PrescriberAccessManagementUserNpiMapResourceImpl(prescriberAccessManagementBo);
		return bean;
	}
	
	@Bean
	public PrescriberAccessManagementUserRoleResource prescriberAccessManagementUserRoleResource(PrescriberAccessManagementBo prescriberAccessManagementBo) {
		PrescriberAccessManagementUserRoleResourceImpl bean = new PrescriberAccessManagementUserRoleResourceImpl(prescriberAccessManagementBo);
		return bean;
	}
	
	@Bean
	public ResteasyResources resteasyResources(
			PrescriberAccessManagementAuditLogResource prescriberAccessManagementAuditLogResource,
			PrescriberAccessmanagementEmailHistoryResource prescriberAccessmanagementEmailHistoryResource,
			PrescriberAccessManagementMaintenanceScheduleResource prescriberAccessManagementMaintenanceScheduleResource,
			PrescriberAccessManagementRequestEntryResource prescriberAccessManagementRequestEntryResource,
			PrescriberAccessManagementUserNpiMapResource prescriberAccessManagementUserNpiMapResource,
			PrescriberAccessManagementUserRoleResource prescriberAccessManagementUserRoleResource) {
		ResteasyResources resources = new ResteasyResources();
		resources.add(prescriberAccessManagementAuditLogResource);
		resources.add(prescriberAccessmanagementEmailHistoryResource);
		resources.add(prescriberAccessManagementMaintenanceScheduleResource);
		resources.add(prescriberAccessManagementRequestEntryResource);
		resources.add(prescriberAccessManagementUserNpiMapResource);
		resources.add(prescriberAccessManagementUserRoleResource);
		return resources;
	}

}
