package com.java8.defalt;

import java.time.ZonedDateTime;

public interface AbstractZoneTimeClient extends TimeClient {
    public ZonedDateTime getZonedDateTime(String zoneString);
}
